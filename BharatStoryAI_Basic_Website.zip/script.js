function generateStory() {
  const story = "एक समय की बात है, एक छोटे से गाँव में एक बच्चा रहता था जिसे कहानियाँ सुनना बहुत पसंद था...";
  document.getElementById("story").innerText = story;
}